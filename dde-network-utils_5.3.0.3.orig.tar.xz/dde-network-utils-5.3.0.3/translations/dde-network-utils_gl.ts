<?xml version="1.0" ?><!DOCTYPE TS><TS language="gl" version="2.1">
<context>
    <name>dde::network::NetworkDevice</name>
    <message>
        <location filename="../networkdevice.cpp" line="81"/>
        <source>Disconnected</source>
        <translation>Desconectado</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="83"/>
        <source>Connecting</source>
        <translation>Conectando</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="84"/>
        <source>Authenticating</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="86"/>
        <source>Obtaining Address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="87"/>
        <source>Connected</source>
        <translation>Conectado</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="89"/>
        <source>Failed</source>
        <translation>Con erros</translation>
    </message>
</context>
</TS>