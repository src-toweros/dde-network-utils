<?xml version="1.0" ?><!DOCTYPE TS><TS language="tr" version="2.1">
<context>
    <name>dde::network::NetworkDevice</name>
    <message>
        <location filename="../networkdevice.cpp" line="97"/>
        <source>Disconnected</source>
        <translation>Bağlantı kesildi</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="99"/>
        <location filename="../networkdevice.cpp" line="139"/>
        <source>Connecting</source>
        <translation>Bağlanıyor</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="100"/>
        <location filename="../networkdevice.cpp" line="140"/>
        <source>Authenticating</source>
        <translation>Kimlik doğrulanıyor</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="102"/>
        <source>Obtaining Address</source>
        <translation>Adres Alınıyor</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="103"/>
        <location filename="../networkdevice.cpp" line="144"/>
        <source>Connected</source>
        <translation>Bağlandı</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="105"/>
        <location filename="../networkdevice.cpp" line="146"/>
        <source>Failed</source>
        <translation>Başarısız</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="115"/>
        <source>Device disabled</source>
        <translation>Aygıt devre dışı</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="119"/>
        <source>Connected but no Internet access</source>
        <translation>Bağlı ancak İnternet erişimi yok</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="123"/>
        <source>Failed to obtain IP address</source>
        <translation>IP adresi alınamadı</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="133"/>
        <source>Network cable unplugged</source>
        <translation>Ağ kablosu takılı değil</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="137"/>
        <source>Not connected</source>
        <translation>Bağlı değil</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="143"/>
        <source>Obtaining IP address</source>
        <translation>IP adresi alınıyor</translation>
    </message>
</context>
</TS>