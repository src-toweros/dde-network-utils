<?xml version="1.0" ?><!DOCTYPE TS><TS language="ko" version="2.1">
<context>
    <name>dde::network::NetworkDevice</name>
    <message>
        <location filename="../networkdevice.cpp" line="97"/>
        <source>Disconnected</source>
        <translation>연결 끊김</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="99"/>
        <location filename="../networkdevice.cpp" line="139"/>
        <source>Connecting</source>
        <translation>연결 중</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="100"/>
        <location filename="../networkdevice.cpp" line="140"/>
        <source>Authenticating</source>
        <translation>인증중</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="102"/>
        <source>Obtaining Address</source>
        <translation>주소 불러오는 중</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="103"/>
        <location filename="../networkdevice.cpp" line="144"/>
        <source>Connected</source>
        <translation>연결됨</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="105"/>
        <location filename="../networkdevice.cpp" line="146"/>
        <source>Failed</source>
        <translation>실패</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="115"/>
        <source>Device disabled</source>
        <translation>디바이스 사용해제됨</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="119"/>
        <source>Connected but no Internet access</source>
        <translation>연결됨, 인터넷 없음</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="123"/>
        <source>Failed to obtain IP address</source>
        <translation>IP 주소 가져오기 실패</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="133"/>
        <source>Network cable unplugged</source>
        <translation>네트워크 케이블 제거됨</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="137"/>
        <source>Not connected</source>
        <translation>연결되지 않음</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="143"/>
        <source>Obtaining IP address</source>
        <translation>IP 주소 가져오는 중</translation>
    </message>
</context>
</TS>