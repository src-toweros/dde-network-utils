<?xml version="1.0" ?><!DOCTYPE TS><TS language="hi_IN" version="2.1">
<context>
    <name>dde::network::NetworkDevice</name>
    <message>
        <location filename="../networkdevice.cpp" line="97"/>
        <source>Disconnected</source>
        <translation>डिस्कनेक्ट है</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="99"/>
        <location filename="../networkdevice.cpp" line="139"/>
        <source>Connecting</source>
        <translation>कनेक्ट हो रहा है </translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="100"/>
        <location filename="../networkdevice.cpp" line="140"/>
        <source>Authenticating</source>
        <translation>प्रमाणीकृत किया जा रहा है</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="102"/>
        <source>Obtaining Address</source>
        <translation>नेटवर्क पता प्राप्त किया जा रहा है</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="103"/>
        <location filename="../networkdevice.cpp" line="144"/>
        <source>Connected</source>
        <translation>कनेक्ट है </translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="105"/>
        <location filename="../networkdevice.cpp" line="146"/>
        <source>Failed</source>
        <translation>विफल रहा</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="115"/>
        <source>Device disabled</source>
        <translation>डिवाइस डिसेबल्ड</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="119"/>
        <source>Connected but no Internet access</source>
        <translation>कनेक्टेड लेकिन इंटरनेट आक्सेस नही है</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="123"/>
        <source>Failed to obtain IP address</source>
        <translation>IP अड्रेस लाने में विफल रहा</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="133"/>
        <source>Network cable unplugged</source>
        <translation>नेटवर्क केबल अनप्लग है </translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="137"/>
        <source>Not connected</source>
        <translation>कनेक्ट नहीं है</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="143"/>
        <source>Obtaining IP address</source>
        <translation>IP अड्रेस प्राप्त किया जा रहा है</translation>
    </message>
</context>
</TS>