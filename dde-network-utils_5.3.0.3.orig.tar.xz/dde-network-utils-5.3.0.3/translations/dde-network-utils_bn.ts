<?xml version="1.0" ?><!DOCTYPE TS><TS language="bn" version="2.1">
<context>
    <name>dde::network::NetworkDevice</name>
    <message>
        <location filename="../networkdevice.cpp" line="97"/>
        <source>Disconnected</source>
        <translation>অসংযুক্ত</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="99"/>
        <location filename="../networkdevice.cpp" line="139"/>
        <source>Connecting</source>
        <translation>সংযুক্ত হচ্ছে</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="100"/>
        <location filename="../networkdevice.cpp" line="140"/>
        <source>Authenticating</source>
        <translation>প্রমাণীকরণ হচ্ছে</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="102"/>
        <source>Obtaining Address</source>
        <translation>ঠিকানা সংগ্রহ করছে</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="103"/>
        <location filename="../networkdevice.cpp" line="144"/>
        <source>Connected</source>
        <translation>সংযুক্ত</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="105"/>
        <location filename="../networkdevice.cpp" line="146"/>
        <source>Failed</source>
        <translation>ব্যর্থ হয়েছে</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="115"/>
        <source>Device disabled</source>
        <translation>ডিভাইস নিষ্ক্রিয়</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="119"/>
        <source>Connected but no Internet access</source>
        <translation>সংযুক্ত কিন্তু কোনো ইন্টারনেট এক্সেস নেই</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="123"/>
        <source>Failed to obtain IP address</source>
        <translation>আইপি ঠিকানা প্রাপ্ত করতে ব্যর্থ</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="133"/>
        <source>Network cable unplugged</source>
        <translation>নেটওয়ার্ক তার তোলা হয়েছে</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="137"/>
        <source>Not connected</source>
        <translation>সংযুক্ত নয়</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="143"/>
        <source>Obtaining IP address</source>
        <translation>আইপি ঠিকানা নেওয়া হচ্ছে</translation>
    </message>
</context>
</TS>