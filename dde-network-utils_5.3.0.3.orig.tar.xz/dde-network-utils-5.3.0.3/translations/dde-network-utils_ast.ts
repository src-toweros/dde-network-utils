<?xml version="1.0" ?><!DOCTYPE TS><TS language="ast" version="2.1">
<context>
    <name>dde::network::NetworkDevice</name>
    <message>
        <location filename="../networkdevice.cpp" line="97"/>
        <source>Disconnected</source>
        <translation>Desconeutáu</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="99"/>
        <location filename="../networkdevice.cpp" line="139"/>
        <source>Connecting</source>
        <translation>Coneutando</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="100"/>
        <location filename="../networkdevice.cpp" line="140"/>
        <source>Authenticating</source>
        <translation>Autenticando</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="102"/>
        <source>Obtaining Address</source>
        <translation>Consiguiendo direición</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="103"/>
        <location filename="../networkdevice.cpp" line="144"/>
        <source>Connected</source>
        <translation>Coneutáu</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="105"/>
        <location filename="../networkdevice.cpp" line="146"/>
        <source>Failed</source>
        <translation>Fallu</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="115"/>
        <source>Device disabled</source>
        <translation>Inhabilitóse&apos;l preséu</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="119"/>
        <source>Connected but no Internet access</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="123"/>
        <source>Failed to obtain IP address</source>
        <translation>Fallu al consiguir la direición IP</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="133"/>
        <source>Network cable unplugged</source>
        <translation>Desconeutóse&apos;l cable de la rede</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="137"/>
        <source>Not connected</source>
        <translation>Nun se coneutó</translation>
    </message>
    <message>
        <location filename="../networkdevice.cpp" line="143"/>
        <source>Obtaining IP address</source>
        <translation>Consiguiendo la direición IP</translation>
    </message>
</context>
</TS>