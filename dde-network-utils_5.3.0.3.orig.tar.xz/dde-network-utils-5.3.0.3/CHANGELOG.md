<a name="0.1.4"></a>
## 0.1.4 (2019-04-15)

#### Bug Fixes

*   connectivity allways NotFull if startup without NotFull ([d5ee0029](d5ee0029))



<a name="0.1.3"></a>
## 0.1.3 (2019-04-10)




<a name="0.1.2"></a>
## 0.1.2 (2019-04-04)


#### Features

*   check network connectivity ([5c044c86](5c044c86))



<a name="0.1.1"></a>
## 0.1.1 (2019-03-27)




<a name="0.1.0"></a>
## 0.1.0 (2019-03-11)


#### Features

*   distribute active connections to devices ([1aeb456c](1aeb456c))



<a name="0.0.9"></a>
## 0.0.9 (2019-01-25)


#### Features

*   there could be multiple active connections for a device ([1077a641](1077a641))

#### Bug Fixes

*   macaddress ([fca6c689](fca6c689))



<a name="0.0.8.2"></a>
## 0.0.8.2 (2018-12-25)


#### Bug Fixes

*   crash when get size of QQueue ([c7b99d90](c7b99d90))



<a name="0.0.8.1"></a>
## 0.0.8.1 (2018-12-10)


#### Bug Fixes

*   device state string typo ([d535744c](d535744c))



<a name="0.0.8"></a>
## 0.0.8 (2018-12-03)


#### Features

*   more detailed device status string ([238b2711](238b2711))



<a name="0.0.7"></a>
## 0.0.7 (2018-11-09)


#### Bug Fixes

*   active connection info of device may not set ([ade29a08](ade29a08))



<a name="0.0.6"></a>
### 0.0.6 (2018-10-25)


#### Bug Fixes

*   active connection identify ([345cccbf](345cccbf))
*   get connection uuid by ap's ssid ([8cec5877](8cec5877))



<a name="0.0.5"></a>
## 0.0.5 (2018-09-10)


#### Bug Fixes

*   new device connections is empty ([f15fd1d9](f15fd1d9))
*   devices list changed signal ([6f95ea9b](6f95ea9b))



<a name="0.0.4"></a>
### 0.0.4 (2018-07-31)




<a name="0.0.3"></a>
### 0.0.3 (2018-07-20)




<a name="0.0.2"></a>
### 0.0.2 (2018-07-20)


#### Bug Fixes

*   add ts ([362c1164](362c1164))
*   spelling mistake ([4f031ae5](4f031ae5))
*   missing install files ([48b5871c](48b5871c))
* **wireless:**  active ap is empty after connection is activated ([1e4bcc09](1e4bcc09))



### 0.0.1
